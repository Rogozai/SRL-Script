Action()
{
	
	lr_start_transaction("roy1 1");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 1",LR_AUTO);

	lr_start_transaction("roy1 2");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_error_message("this is error message");
	lr_think_time(1);
	lr_end_transaction("roy1 2",LR_AUTO);

	lr_start_transaction("roy1 3");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 3",LR_AUTO);

	lr_start_transaction("roy1 4");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 4",LR_AUTO);	
	
	lr_start_transaction("roy1 5");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 5",LR_AUTO);

	lr_start_transaction("roy1 6");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 6",LR_AUTO);	
	
	lr_start_transaction("roy1 7");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 7",LR_AUTO);	
	
	lr_start_transaction("roy1 8");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 8",LR_AUTO);	
	
	lr_start_transaction("roy1 9");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 9",LR_AUTO);	
	
	lr_start_transaction("roy1 10");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 10",LR_AUTO);		

	lr_start_transaction("roy1 11");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 11",LR_AUTO);

	lr_start_transaction("roy1 12");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_error_message("this is error message");
	lr_think_time(1);
	lr_end_transaction("roy1 12",LR_AUTO);

	lr_start_transaction("roy1 13");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 13",LR_AUTO);

	lr_start_transaction("roy1 14");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 14",LR_AUTO);	
	
	lr_start_transaction("roy1 15");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 15",LR_AUTO);

	lr_start_transaction("roy1 16");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 16",LR_AUTO);	
	
	lr_start_transaction("roy1 17");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 17",LR_AUTO);	
	
	lr_start_transaction("roy1 18");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 18",LR_AUTO);	
	
	lr_start_transaction("roy1 19");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 19",LR_AUTO);	
	
	lr_start_transaction("roy1 20");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 20",LR_AUTO);	
	
		lr_start_transaction("roy1 21");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 21",LR_AUTO);

	lr_start_transaction("roy1 22");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_error_message("this is error message");
	lr_think_time(1);
	lr_end_transaction("roy1 22",LR_AUTO);

	lr_start_transaction("roy1 23");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 23",LR_AUTO);

	lr_start_transaction("roy1 24");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 24",LR_AUTO);	
	
	lr_start_transaction("roy1 25");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 25",LR_AUTO);

	lr_start_transaction("roy1 26");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 26",LR_AUTO);	
	
	lr_start_transaction("roy1 27");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 27",LR_AUTO);	
	
	lr_start_transaction("roy1 28");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 28",LR_AUTO);	
	
	lr_start_transaction("roy1 29");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 29",LR_AUTO);	
	
	lr_start_transaction("roy1 30");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 30",LR_AUTO);	
	
	
	lr_start_transaction("roy1 31");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 31",LR_AUTO);

	lr_start_transaction("roy1 32");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_error_message("this is error message");
	lr_think_time(1);
	lr_end_transaction("roy1 32",LR_AUTO);

	lr_start_transaction("roy1 33");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 33",LR_AUTO);

	lr_start_transaction("roy1 34");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 34",LR_AUTO);	
	
	lr_start_transaction("roy1 35");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 35",LR_AUTO);

	lr_start_transaction("roy1 36");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 36",LR_AUTO);	
	
	lr_start_transaction("roy1 37");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 37",LR_AUTO);	
	
	lr_start_transaction("roy1 38");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 38",LR_AUTO);	
	
	lr_start_transaction("roy1 39");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 39",LR_AUTO);	
	
	lr_start_transaction("roy1 40");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 40",LR_AUTO);	
	
	lr_start_transaction("roy1 41");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 41",LR_AUTO);

	lr_start_transaction("roy1 42");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_error_message("this is error message");
	lr_think_time(1);
	lr_end_transaction("roy1 42",LR_AUTO);

	lr_start_transaction("roy1 43");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 43",LR_AUTO);

	lr_start_transaction("roy1 44");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 44",LR_AUTO);	
	
	lr_start_transaction("roy1 45");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 45",LR_AUTO);

	lr_start_transaction("roy1 46");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 46",LR_AUTO);	
	
	lr_start_transaction("roy1 47");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 47",LR_AUTO);	
	
	lr_start_transaction("roy1 48");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 48",LR_AUTO);	
	
	lr_start_transaction("roy1 49");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 49",LR_AUTO);	
	
	lr_start_transaction("roy1 50");
	lr_user_data_point("mic_recv", 1000);
	lr_user_data_point("HTTP_200", 1);
	lr_think_time(1);
	lr_end_transaction("roy1 50",LR_AUTO);	
	return 0;
}
