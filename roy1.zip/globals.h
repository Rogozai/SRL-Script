#ifndef _GLOBALS_H
#define _GLOBALS_H


int stime = 2000;
int scale;
char  *os;
int mystime;


//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "web_api.h"
#include "lrw_custom_body.h"

//--------------------------------------------------------------------
// Global Variables

int ITERATION_NUM=0;

#endif // _GLOBALS_H
