//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("Transaction 1");
	truclient_step("1", "Navigate to '52.39.153.71'", "snapshot=Action_1.inf");
	lr_end_transaction("Transaction 1",0);
	lr_start_transaction("Transaction 2");
	truclient_step("3", "Click on Go to second page button", "snapshot=Action_3.inf");
	lr_end_transaction("Transaction 2",0);
	lr_start_transaction("Transaction 3");
	truclient_step("7", "Click on Back to home button", "snapshot=Action_7.inf");
	lr_end_transaction("Transaction 3",0);

	return 0;
}
